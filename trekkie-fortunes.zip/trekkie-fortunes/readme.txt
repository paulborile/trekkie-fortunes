=== Trekkie Fortunes ===
Contributors: Paul Stephen Borile
Requires at least: 3.0
Stable tag: 1.0
Tested up to: 4.0

Star Trek fortunes used to be the first thing I saw in the morning when loggin into system for software development. Just wanted to have the same thing in my wordpress admin dashboard. Thanks to Hello Dolly for inspiration.

== Description ==

Star Trek fortunes used to be the first thing I saw in the morning when loggin into system for software development. Just wanted to have the same thing in my wordpress admin dashboard. Thanks to Hello Dolly for inspiration.
